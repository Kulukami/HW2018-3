import os
import time
class prePro():
    def __init__(self,ecsDataPath,inputFilePath,resultFilePath):        
        InputInfos=self.readInput(inputFilePath)
        self.phsDev=InputInfos[0] # (int(cpu),int(ram),int(disk))
        self.virDevs=InputInfos[1]# dict[ID]:(int(cpus),int(rams))
        self.firstCare=InputInfos[2]# CPU or MEM
        self.predicStrTime=InputInfos[3]# timestamp
        self.predicEndTime=InputInfos[4]# timestamp
        
        self.pool=[[],[],[],[],[],
                   [],[],[],[],[],
                   [],[],[],[],[]]

        self.legi={"flavor1":0,"flavor2":1,"flavor3":2,"flavor4":3,"flavor5":4,
                   "flavor6":5,"flavor7":6,"flavor8":7,"flavor9":8,"flavor10":9,
                   "flavor11":10,"flavor12":11,"flavor13":12,
                   "flavor14":13,"flavor15":14}
        # Counts of flavor0 ~ flavor15
        with open(ecsDataPath, 'r') as f:
            lines = f.readlines()  
        self.startime=self.date2read(lines[0].strip().split('\t')[2])
        self.endstime=self.date2read(lines[-1].strip().split('\t')[2])+86400
        for line in lines:
            self.mkpool(line)
            
        self.results=self.predict()
        
        self.putPhs(resultFilePath)
        
    def date2read(self,dt):
        dt = dt.split()[0]
        return time.mktime(time.strptime(dt,'%Y-%m-%d'))    
    
    def readTime(self,timeStr):
        return time.mktime(time.strptime(timeStr,'%Y-%m-%d %H:%M:%S'))

    def time2read(self,dt):
        dt = dt.split('\t')[0]
        return time.mktime(time.strptime(dt,'%Y-%m-%d %H:%M:%S'))

    def timeMh(self,d1,d2):
        #return int((d1-d2)/604800) #a week
        #return int((d1-d2)/3600) #a hour
        return int((d1-d2)/86400) #a day

    def readInput(self,inputFilePath):
        if os.path.exists(inputFilePath):
            with open(inputFilePath,'r') as f:
                cpu,ram,disk=f.readline().strip().split()
                f.readline()
                phsDev=(int(cpu),int(ram),int(disk))
                virDevCount=int(f.readline().strip())
                virDevs={}
                for i in range(virDevCount):
                    Id,cpus,rams=f.readline().strip().split()
                    virDevs[Id]=(int(cpus),int(rams))
                f.readline()
                firstCare=f.readline().strip()
                f.readline()
                predicStrTime=self.readTime(f.readline().strip())
                predicEndTime=self.readTime(f.readline().strip())
                #print(phsDev,virDevs,firstCare,predicStrTime,predicEndTime)
            return phsDev,virDevs,firstCare,predicStrTime,predicEndTime

        else:
            print('file not exist: ' + file_path)
            return None
    
    def mkpool(self,raw):
        flavor,tm=raw.strip().split("\t")[1:]
        TM=self.time2read(tm)
        if flavor in self.virDevs:
            hourTM=self.timeMh(TM,self.startime)
            while hourTM - len(self.pool[self.legi[flavor]]) >= 0:
                self.pool[self.legi[flavor]].append(0)       
            self.pool[self.legi[flavor]][hourTM]+=1
            
    def predict(self):
        predicts={}
        predTime=self.predicEndTime - self.predicStrTime
        dataTime=self.endstime-self.startime     
        for i in self.virDevs:
            counts= predTime* sum(self.pool[self.legi[i]])/dataTime
            predicts[i]=int(counts)
        return predicts
    
    def putPhs(self,resultFile):
        Hdev=list(self.phsDev)
        HDs={0:list(Hdev[:2])}
        HDf={0:{"flavor1":0,"flavor2":0,"flavor3":0,"flavor4":0,"flavor5":0,
                "flavor6":0,"flavor7":0,"flavor8":0,"flavor9":0,"flavor10":0,
                "flavor11":0,"flavor12":0,"flavor13":0,"flavor14":0,"flavor15":0}}
        
        def selectHard(hdf,hds,dev):
            for i in hds:
                if hds[i][0] > self.virDevs[dev][0] and hds[i][1] > self.virDevs[dev][1]/1024.0:
                    return i
            hds[len(hds)]=list(Hdev[:2])
            hdf[len(hdf)]={"flavor1":0,"flavor2":0,"flavor3":0,"flavor4":0,"flavor5":0,
                           "flavor6":0,"flavor7":0,"flavor8":0,"flavor9":0,"flavor10":0,
                           "flavor11":0,"flavor12":0,"flavor13":0,"flavor14":0,"flavor15":0}

            return len(hds)-1

        def sv(hdf=HDf,hds=HDs,predev=self.results):  
            for i in predev:
                while predev[i]>0:
                    predev[i] -= 1
                    hdev=selectHard(hdf,hds,i)
                    cpu,ram=self.virDevs[i]
                    hds[hdev][0] -= cpu
                    hds[hdev][1] -= ram/1024.0
                    hdf[hdev][i] += 1

        f=open(resultFile,"w")
        totals = int(sum([i for i in self.results.values()]))
        f.writelines([str(totals),'\n'])
        
        for ID,Count in self.results.iteritems():
            f.writelines([ID," ",str(int(Count)),'\n'])
        sv()
        f.writelines(['\n'])
        
        f.writelines([str(len(HDf)),'\n'])
        for each in HDf:
            f.writelines([str(each+1)])
            for i in HDf[each]:
                if i in self.results:
                    f.writelines([' ',i,' ',str(int(HDf[each][i]))])
            f.writelines(['\n'])

        #print(HDf)
        f.close()
