import os
import time
class prePro():
    def __init__(self,ecsDataPath,inputFilePath,resultFilePath):        
        InputInfos=self.readInput(inputFilePath)
        self.phsDev=InputInfos[0] # (int(cpu),int(ram),int(disk))
        self.virDevs=InputInfos[1]# dict[ID]:(int(cpus),int(rams))
        self.firstCare=InputInfos[2]# CPU or MEM
        self.predicStrTime=InputInfos[3]# timestamp
        self.predicEndTime=InputInfos[4]# timestamp
        
        self.predicLength=self.predicEndTime-self.predicStrTime
        
        self.pool=[[],[],[],[],[],
                   [],[],[],[],[],
                   [],[],[],[],[]]

        self.legi={"flavor1":0,"flavor2":1,"flavor3":2,"flavor4":3,"flavor5":4,
                   "flavor6":5,"flavor7":6,"flavor8":7,"flavor9":8,"flavor10":9,
                   "flavor11":10,"flavor12":11,"flavor13":12,
                   "flavor14":13,"flavor15":14}
        # Counts of flavor0 ~ flavor15
        with open(ecsDataPath, 'r') as f:
            lines = f.readlines()  
        self.startime=self.date2read(lines[0].strip().split('\t')[2])
        self.endstime=self.date2read(lines[-1].strip().split('\t')[2])+86400
        for line in lines:
            self.mkpool(line)
        
        #print(self.pool)
        self.results=self.predict()
        #print(self.results)
        self.putPhs(resultFilePath)
        
    def date2read(self,dt):
        dt = dt.split()[0]
        return time.mktime(time.strptime(dt,'%Y-%m-%d'))    
    
    def readTime(self,timeStr):
        return time.mktime(time.strptime(timeStr,'%Y-%m-%d %H:%M:%S'))

    def time2read(self,dt):
        dt = dt.split('\t')[0]
        return time.mktime(time.strptime(dt,'%Y-%m-%d %H:%M:%S'))

    def timeMh(self,d1,d2):
        #return int((d1-d2)/604800) #a week
        #return int((d1-d2)/3600) #a hour
        return int((d1-d2)/self.predicLength) #a day

    def readInput(self,inputFilePath):
        if os.path.exists(inputFilePath):
            with open(inputFilePath,'r') as f:
                cpu,ram,disk=f.readline().strip().split()
                f.readline()
                phsDev=(int(cpu),int(ram),int(disk))
                virDevCount=int(f.readline().strip())
                virDevs={}
                for i in range(virDevCount):
                    Id,cpus,rams=f.readline().strip().split()
                    virDevs[Id]=(int(cpus),int(rams))
                f.readline()
                firstCare=f.readline().strip()
                f.readline()
                predicStrTime=self.readTime(f.readline().strip())
                predicEndTime=self.readTime(f.readline().strip())
                #print(phsDev,virDevs,firstCare,predicStrTime,predicEndTime)
            return phsDev,virDevs,firstCare,predicStrTime,predicEndTime

        else:
            print('file not exist: ' + file_path)
            return None
    
    def mkpool(self,raw):
        flavor,tm=raw.strip().split("\t")[1:]
        TM=self.time2read(tm)
        if flavor in self.virDevs:
            hourTM=self.timeMh(TM,self.startime)
            while hourTM - len(self.pool[self.legi[flavor]]) >= 0:
                self.pool[self.legi[flavor]].append(0)       
            self.pool[self.legi[flavor]][hourTM]+=1
            
    def predict(self):
        predicts={}
        predTime=self.predicEndTime - self.predicStrTime
        dataTime=self.endstime-self.startime     
        for i in self.virDevs:
            Ti=GradianDecent(self.pool[self.legi[i]],1000,10**-5)
            Ti.Train()
            Xi=int(dataTime/float(predTime))
            #print("Xi",Xi)
            #print("J",Ti.J)
            counts= Ti.h(Xi)
            predicts[i]=int(round(counts))
        return predicts
   
    def putPhs(self,resultFile):
        results=self.results.copy()
        Hdev=list(self.phsDev)
        HDs={0:list(Hdev[:2])}
        HDf={0:{"flavor1":0,"flavor2":0,"flavor3":0,"flavor4":0,"flavor5":0,
                "flavor6":0,"flavor7":0,"flavor8":0,"flavor9":0,"flavor10":0,
                "flavor11":0,"flavor12":0,"flavor13":0,"flavor14":0,"flavor15":0}}
        
        def selectHard(hdf,hds,dev):
            for i in hds:
                if hds[i][0] > self.virDevs[dev][0] and hds[i][1] > self.virDevs[dev][1]/1024.0:
                    return i
            hds[len(hds)]=list(Hdev[:2])
            hdf[len(hdf)]={"flavor1":0,"flavor2":0,"flavor3":0,"flavor4":0,"flavor5":0,
                           "flavor6":0,"flavor7":0,"flavor8":0,"flavor9":0,"flavor10":0,
                           "flavor11":0,"flavor12":0,"flavor13":0,"flavor14":0,"flavor15":0}

            return len(hds)-1

        def isHave(predev=self.results):
            for i in predev:
                if predev[i]>0:
                    return True
            return False

        def genKeys(predev=self.results):
            keys = ["flavor15","flavor14","flavor13","flavor12","flavor11","flavor10","flavor9","flavor8","flavor7","flavor6","flavor5","flavor4","flavor3","flavor2","flavor1"]
            res = []
            #print predev
            for key in keys:
                if key in predev.keys():
                    for i in range(predev[key]):
                        res.append(key)
            return res

        def sv(hdf=HDf,hds=HDs,predev=results):
            keys = genKeys()
            firstC = 0 
            if firstC == 0 or firstC == 1:
              
                while isHave(predev):
                    isPlace = False
                  
                    for i in hds:
                       
                        for key in keys:
                         
                            if predev[key] > 0:
                                if hds[i][0] >= self.virDevs[key][0]:
                             
                                    if hds[i][1] >= self.virDevs[key][1]/1024.0:
                                        cpu,ram=self.virDevs[key]
                                       
                                        hds[i][0] -= cpu
                                        hds[i][1] -= ram/1024.0
                                       
                                        hdf[i][key] += 1
                                       
                                        predev[key] -= 1
                                      
                                        keys.remove(key)
                                        isPlace = True
                    if isPlace == False :
                        hds[len(hds)]=Hdev[:]
                        hdf[len(hdf)]={"flavor1":0,"flavor2":0,"flavor3":0,"flavor4":0,"flavor5":0,"flavor6":0,"flavor7":0,"flavor8":0,"flavor9":0,"flavor10":0,"flavor11":0,"flavor12":0,"flavor13":0,"flavor14":0,"flavor15":0}

        f=open(resultFile,"w")
        totals = int(sum([i for i in results.values()]))
        f.writelines([str(totals),'\n'])
        
        for ID,Count in results.iteritems():
            f.writelines([ID," ",str(int(Count)),'\n'])
        sv()
        f.writelines(['\n'])
        
        f.writelines([str(len(HDf)),'\n'])
        for each in HDf:
            f.writelines([str(each+1)])
            for i in HDf[each]:
                if i in results:
                    f.writelines([' ',i,' ',str(int(HDf[each][i]))])
            f.writelines(['\n'])

        #print(HDf)
        f.close()


"""       
if __name__ == "__main__":
    print 'main function begin.'
    if len(sys.argv) != 4:
        print 'parameter is incorrect!'
        print 'Usage: python esc.py ecsDataPath inputFilePath resultFilePath'
        exit(1)
    # Read the input files
    
    ecsDataPath = sys.argv[1]
    inputFilePath = sys.argv[2]
    resultFilePath = sys.argv[3]
    result=prePro(ecsDataPath,inputFilePath,resultFilePath)
"""
##

class GradianDecent():
    def __init__(self,Y,trainL=500,learningRate=10**-5,
                 A = 0.0000057142857142857145,
                 B = 0.014285714285714285,
                 C = 0.0):
        self.X=range(len(Y))
        self.Y=Y
        self.m=len(self.Y)
        self.trainL=trainL
        self.learningRate=learningRate

        self.A = A #np.random.randint(4)
        self.B = B #np.random.randint(5)
        self.C = C #np.random.randint(6)


        #print(A,B,C,m)
        self.J=[]
        
    def Train(self):
        for each in range(self.trainL):
            ja=self.JFA(self.X,self.Y,self.A,self.B,self.C,self.m)
            jb=self.JFB(self.X,self.Y,self.A,self.B,self.C,self.m)
            jc=self.JFC(self.X,self.Y,self.A,self.B,self.C,self.m)
            #print("ja",ja,"\tjb",jb,"\tjc",jc)
            self.A = self.A - self.learningRate * ja
            self.B = self.B - self.learningRate * jb
            self.C = self.C - self.learningRate * jc
            self.J.append(self.Cost(self.X,self.Y,self.A,self.B,self.C,self.m))
    
    def h(self,x):
        return  self.A*x **2  + self.B*x + self.C

    def JFA(self,X,Y,A,B,C,m):
        s=0.
        for i in range(m):
            s += 2*X[i] **2 *( A*X[i] **2  + B*X[i] + C - Y[i])
        return s/float(m)

    def JFB(self,X,Y,A,B,C,m):
        s=0.
        for i in range(m):
            s += 2*X[i] *( A*X[i] **2  + B*X[i] + C - Y[i])
        return s/float(m)

    def JFC(self,X,Y,A,B,C,m):
        s=0.
        for i in range(m):
            s +=  2*(A*X[i] **2  + B*X[i] + C - Y[i])
        return s/float(m)

    def Cost(self,X,Y,A,B,C,m):
        s=0.
        for i in range(m):
            s +=  abs(A*X[i] **2  + B*X[i] + C - Y[i])
        return s/float(m)

