# coding=utf-8
import sys
import os
import time
from predictor import prePro

        
if __name__ == "__main__":
    print 'main function begin.'
    if len(sys.argv) != 4:
        print 'parameter is incorrect!'
        print 'Usage: python esc.py ecsDataPath inputFilePath resultFilePath'
        exit(1)
    # Read the input files
    ecsDataPath = sys.argv[1]
    inputFilePath = sys.argv[2]
    resultFilePath = sys.argv[3]
    result=prePro(ecsDataPath,inputFilePath,resultFilePath)
